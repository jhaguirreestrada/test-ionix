package org.jaguirre.springcloud.msvc.usuarios.models.dto;

import java.util.ArrayList;

public class ResultSearch {
    private ArrayList<Item> items;

    public ArrayList<Item> getItems() {
        return items;
    }

    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }
}
