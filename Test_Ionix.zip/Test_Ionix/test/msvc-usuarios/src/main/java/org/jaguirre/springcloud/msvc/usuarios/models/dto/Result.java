package org.jaguirre.springcloud.msvc.usuarios.models.dto;

public class Result {
    private int registerCount;

    public int getRegisterCount() {
        return registerCount;
    }

    public void setRegisterCount(int registerCount) {
        this.registerCount = registerCount;
    }
}
